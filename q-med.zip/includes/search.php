<div class="popup-search-box d-none d-lg-block">
  <button class="searchClose"><i class="fal fa-times"></i></button>
  <form action="#">
      <input type="text" placeholder="What are you looking for?">
      <button type="submit"><i class="fal fa-search"></i></button>
  </form>
</div>
