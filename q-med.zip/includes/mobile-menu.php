<div class="th-menu-wrapper">
  <div class="th-menu-area text-center">
      <button class="th-menu-toggle"><i class="fal fa-times"></i></button>
      <div class="mobile-logo">
          <a href="/"><img src="assets/img/q-med-logo.jpg" style="width: 200px; height: auto" alt="Mediax"></a>
      </div>
      <div class="th-mobile-menu">
          <ul>
              <li class="menu-item-has-children">
                  <a href="/">Home</a>
                  
              </li>
              <li><a href="about">About Us</a></li>
              <li class="">
                  <a href="services">Services</a>
              </li>
              <li>
                  <a href="contact">Contact</a>
              </li>
              <li>
                <button type="button" class="th-btn style5 appointmentInfo">Appointment Now</button>
              </li>
          </ul>
      </div>
  </div>
</div>
